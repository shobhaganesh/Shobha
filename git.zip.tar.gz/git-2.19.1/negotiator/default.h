#ifndef NEGOTIATOR_DEFAULT_H
#define NEGOTIATOR_DEFAULT_H

struct fetch_negotiator;

void default_negotiator_init(struct fetch_negotiator *negotiator);

#endif
